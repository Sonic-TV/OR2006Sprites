Photoshop Actions to Export All system Button prompts:
- Make sure you have installed the DDS Texture Export Plugin "https://github.com/GameTechDev/Intel-Texture-Works-Plugin/releases/"
- Extract the zip and you will find empty folders and the Photoshop Actions.
- Put the folders in "C:\" So the action will export the textures to the correct place.
- Add the actions to Photoshop.
- Each texture have its set of button prompts per-system.
- Keep the group/folder structure inside the PSDs or the Photoshop Actions will break and won't work anymore.
- Open the texture that you want to update/export and then use the respective texture action and the desired button prompt.
